import{c as r,s as e}from"./flowDiagram-IUGLLWBU-CUtO4NZ9.js";import{_ as a}from"./index-C2WowOdo.js";import"./chunk-5VM5RSS4-RduFAwna.js";import"./chunk-XXDRQBXY-R5G4hE-W.js";import"./chunk-VQ5W62QI-CZu_fAao.js";import"./chunk-55XCU76K-e4-ZRssQ.js";import"./channel-Clf_Tziv.js";var o=a(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=r({styles:s});export{f as diagram};
